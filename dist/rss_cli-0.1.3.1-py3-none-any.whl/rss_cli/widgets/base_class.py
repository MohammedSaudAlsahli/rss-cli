from rich.console import Console
from rich.prompt import Prompt


class BaseClass:
    _console = Console()
    _prompt = Prompt()
